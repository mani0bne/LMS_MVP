import React, { useState } from 'react';
import EmployeeForm from './components/EmployeeForm';
import LeaveApplicationForm from './components/LeaveApplicationForm';
import LeaveApprovalDashboard from './components/LeaveApprovalDashboard';

function App() {
  const [currentView, setCurrentView] = useState('dashboard');
  const [selectedEmployeeId, setSelectedEmployeeId] = useState(null);
  const [currentUser] = useState({
    _id: '507f1f77bcf86cd799439011', // Mock manager ID
    role: 'manager'
  });

  const renderCurrentView = () => {
    switch (currentView) {
      case 'add-employee':
        return <EmployeeForm onEmployeeAdded={() => setCurrentView('dashboard')} />;
      case 'apply-leave':
        return (
          <LeaveApplicationForm 
            employeeId={selectedEmployeeId} 
            onLeaveApplied={() => setCurrentView('dashboard')} 
          />
        );
      case 'approvals':
        return <LeaveApprovalDashboard managerId={currentUser._id} />;
      default:
        return <LeaveApprovalDashboard managerId={currentUser._id} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <h1 className="text-xl font-bold text-gray-900">Leave Management System</h1>
            </div>
            <div className="flex items-center space-x-4">
              <button
                onClick={() => setCurrentView('dashboard')}
                className={`px-3 py-2 rounded-md text-sm font-medium ${
                  currentView === 'dashboard' 
                    ? 'bg-blue-100 text-blue-700' 
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                Dashboard
              </button>
              <button
                onClick={() => setCurrentView('add-employee')}
                className={`px-3 py-2 rounded-md text-sm font-medium ${
                  currentView === 'add-employee' 
                    ? 'bg-blue-100 text-blue-700' 
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                Add Employee
              </button>
              <button
                onClick={() => {
                  setSelectedEmployeeId('507f1f77bcf86cd799439012'); // Mock employee ID
                  setCurrentView('apply-leave');
                }}
                className={`px-3 py-2 rounded-md text-sm font-medium ${
                  currentView === 'apply-leave' 
                    ? 'bg-blue-100 text-blue-700' 
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                Apply Leave
              </button>
              <button
                onClick={() => setCurrentView('approvals')}
                className={`px-3 py-2 rounded-md text-sm font-medium ${
                  currentView === 'approvals' 
                    ? 'bg-blue-100 text-blue-700' 
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                Approvals
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        {renderCurrentView()}
      </main>
    </div>
  );
}

export default App;
