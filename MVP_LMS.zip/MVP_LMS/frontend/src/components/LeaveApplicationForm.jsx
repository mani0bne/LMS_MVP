// components/LeaveApplicationForm.jsx
import React, { useState, useEffect } from 'react';
import axios from 'axios';

const LeaveApplicationForm = ({ employeeId, onLeaveApplied }) => {
  const [formData, setFormData] = useState({
    leaveType: '',
    startDate: '',
    endDate: '',
    reason: '',
    emergencyLeave: false
  });
  const [leaveBalance, setLeaveBalance] = useState([]);
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [totalDays, setTotalDays] = useState(0);

  useEffect(() => {
    if (employeeId) {
      fetchLeaveBalance();
    }
  }, [employeeId]);

  useEffect(() => {
    if (formData.startDate && formData.endDate) {
      calculateTotalDays();
    }
  }, [formData.startDate, formData.endDate]);

  const fetchLeaveBalance = async () => {
    try {
      const response = await axios.get(`http://localhost:5000/api/leaves/balance/${employeeId}`);
      setLeaveBalance(response.data);
    } catch (error) {
      console.error('Failed to fetch leave balance:', error);
    }
  };

  const calculateTotalDays = () => {
    const start = new Date(formData.startDate);
    const end = new Date(formData.endDate);
    
    if (start > end) {
      setTotalDays(0);
      return;
    }
    
    let count = 0;
    const current = new Date(start);
    
    while (current <= end) {
      const dayOfWeek = current.getDay();
      if (dayOfWeek !== 0 && dayOfWeek !== 6) { // Exclude weekends
        count++;
      }
      current.setDate(current.getDate() + 1);
    }
    
    setTotalDays(count);
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.leaveType) newErrors.leaveType = 'Leave type is required';
    if (!formData.startDate) newErrors.startDate = 'Start date is required';
    if (!formData.endDate) newErrors.endDate = 'End date is required';
    if (!formData.reason.trim()) newErrors.reason = 'Reason is required';
    
    if (formData.startDate && formData.endDate) {
      const start = new Date(formData.startDate);
      const end = new Date(formData.endDate);
      const today = new Date();
      
      if (start > end) {
        newErrors.endDate = 'End date cannot be before start date';
      }
      
      if (!formData.emergencyLeave && start < today) {
        newErrors.startDate = 'Cannot apply leave for past dates';
      }
      
      // Check leave balance
      const balance = leaveBalance.find(b => b.leaveType === formData.leaveType);
      if (balance && !formData.emergencyLeave && balance.available < totalDays) {
        newErrors.leaveType = `Insufficient balance. Available: ${balance.available}`;
      }
    }
    
    return newErrors;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    const newErrors = validateForm();
    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }
    
    setLoading(true);
    setErrors({});
    
    try {
      const response = await axios.post('http://localhost:5000/api/leaves', {
        ...formData,
        employeeId
      });
      alert('Leave application submitted successfully!');
      setFormData({
        leaveType: '',
        startDate: '',
        endDate: '',
        reason: '',
        emergencyLeave: false
      });
      setTotalDays(0);
      fetchLeaveBalance(); // Refresh balance
      if (onLeaveApplied) onLeaveApplied(response.data);
    } catch (error) {
      setErrors({ submit: error.response?.data?.error || 'Failed to submit leave application' });
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const selectedBalance = leaveBalance.find(b => b.leaveType === formData.leaveType);

  return (
    <div className="max-w-2xl mx-auto bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-2xl font-bold mb-4">Apply for Leave</h2>
      
      {/* Leave Balance Display */}
      <div className="mb-6 p-4 bg-gray-50 rounded-lg">
        <h3 className="text-lg font-semibold mb-2">Current Leave Balance</h3>
        <div className="grid grid-cols-3 gap-4">
          {leaveBalance.map(balance => (
            <div key={balance.leaveType} className="text-center">
              <div className="text-sm text-gray-600 capitalize">{balance.leaveType}</div>
              <div className="text-xl font-bold text-blue-600">{balance.available}</div>
              <div className="text-xs text-gray-500">Available</div>
            </div>
          ))}
        </div>
      </div>
      
      {errors.submit && (
        <div className="mb-4 p-3 bg-red-100 border border-red-400 text-red-700 rounded">
          {errors.submit}
        </div>
      )}
      
      <form onSubmit={handleSubmit}>
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Leave Type *
            </label>
            <select
              name="leaveType"
              value={formData.leaveType}
              onChange={handleChange}
              className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                errors.leaveType ? 'border-red-500' : 'border-gray-300'
              }`}
            >
              <option value="">Select Leave Type</option>
              <option value="annual">Annual Leave</option>
              <option value="sick">Sick Leave</option>
              <option value="personal">Personal Leave</option>
              <option value="emergency">Emergency Leave</option>
            </select>
            {errors.leaveType && <p className="text-red-500 text-sm mt-1">{errors.leaveType}</p>}
            {selectedBalance && (
              <p className="text-sm text-gray-600 mt-1">
                Available: {selectedBalance.available} days
              </p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Emergency Leave
            </label>
            <div className="flex items-center mt-3">
              <input
                type="checkbox"
                name="emergencyLeave"
                checked={formData.emergencyLeave}
                onChange={handleChange}
                className="mr-2 h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
              />
              <span className="text-sm text-gray-700">This is an emergency leave</span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Start Date *
            </label>
            <input
              type="date"
              name="startDate"
              value={formData.startDate}
              onChange={handleChange}
              min={formData.emergencyLeave ? '' : new Date().toISOString().split('T')[0]}
              className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                errors.startDate ? 'border-red-500' : 'border-gray-300'
              }`}
            />
            {errors.startDate && <p className="text-red-500 text-sm mt-1">{errors.startDate}</p>}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              End Date *
            </label>
            <input
              type="date"
              name="endDate"
              value={formData.endDate}
              onChange={handleChange}
              min={formData.startDate || (formData.emergencyLeave ? '' : new Date().toISOString().split('T')[0])}
              className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                errors.endDate ? 'border-red-500' : 'border-gray-300'
              }`}
            />
            {errors.endDate && <p className="text-red-500 text-sm mt-1">{errors.endDate}</p>}
          </div>
        </div>

        {totalDays > 0 && (
          <div className="mb-4 p-3 bg-blue-50 border border-blue-200 rounded">
            <p className="text-blue-800">
              <strong>Total Business Days:</strong> {totalDays} days
              {selectedBalance && !formData.emergencyLeave && (
                <span className={totalDays > selectedBalance.available ? 'text-red-600 ml-2' : 'text-green-600 ml-2'}>
                  {totalDays > selectedBalance.available ? '(Exceeds available balance)' : '(Within available balance)'}
                </span>
              )}
            </p>
          </div>
        )}

        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Reason for Leave *
          </label>
          <textarea
            name="reason"
            value={formData.reason}
            onChange={handleChange}
            rows="4"
            className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 ${
              errors.reason ? 'border-red-500' : 'border-gray-300'
            }`}
            placeholder="Please provide a reason for your leave..."
          />
          {errors.reason && <p className="text-red-500 text-sm mt-1">{errors.reason}</p>}
        </div>

        <button
          type="submit"
          disabled={loading}
          className="w-full bg-blue-600 text-white py-3 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {loading ? 'Submitting Application...' : 'Submit Leave Application'}
        </button>
      </form>
    </div>
  );
};

export default LeaveApplicationForm;