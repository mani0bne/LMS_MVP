// components/LeaveApprovalDashboard.jsx
import React, { useState, useEffect } from 'react';
import axios from 'axios';

const LeaveApprovalDashboard = ({ managerId }) => {
  const [pendingLeaves, setPendingLeaves] = useState([]);
  const [loading, setLoading] = useState(true);
  const [processingId, setProcessingId] = useState(null);

  useEffect(() => {
    fetchPendingLeaves();
  }, [managerId]);

  const fetchPendingLeaves = async () => {
    try {
      setLoading(true);
      // In real implementation, this would filter by manager's team
      const response = await axios.get('http://localhost:5000/api/leaves?status=pending');
      setPendingLeaves(Array.isArray(response.data) ? response.data : response.data.leaves || []);

    } catch (error) {
      console.error('Failed to fetch pending leaves:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleApproval = async (leaveId, action, rejectionReason = '') => {
    try {
      setProcessingId(leaveId);
      
      await axios.put(`http://localhost:5000/api/leaves/${leaveId}/${action}`, {
        approverId: managerId,
        rejectionReason
      });
      
      alert(`Leave ${action}d successfully!`);
      fetchPendingLeaves(); // Refresh the list
    } catch (error) {
      alert(error.response?.data?.error || `Failed to ${action} leave`);
    } finally {
      setProcessingId(null);
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      weekday: 'short',
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto p-6">
      <h2 className="text-2xl font-bold mb-6">Pending Leave Approvals</h2>
      
      {pendingLeaves.length === 0 ? (
        <div className="text-center py-12 bg-gray-50 rounded-lg">
          <div className="text-gray-500 text-lg">No pending leave requests</div>
          <div className="text-gray-400 text-sm mt-2">All caught up! 🎉</div>
        </div>
      ) : (
        <div className="space-y-4">
          {pendingLeaves.map((leave) => (
            <div key={leave._id} className="bg-white border border-gray-200 rounded-lg p-6 shadow-sm">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">
                    {leave.employeeId?.name || 'Unknown Employee'}
                  </h3>
                  <p className="text-sm text-gray-600">
                    {leave.employeeId?.employeeId} • {leave.employeeId?.department}
                  </p>
                </div>
                <div className="flex items-center space-x-2">
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                    leave.emergencyLeave 
                      ? 'bg-red-100 text-red-800' 
                      : 'bg-yellow-100 text-yellow-800'
                  }`}>
                    {leave.emergencyLeave ? 'Emergency' : 'Regular'}
                  </span>
                  <span className="px-3 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800 capitalize">
                    {leave.leaveType}
                  </span>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                <div>
                  <div className="text-sm text-gray-600">Duration</div>
                  <div className="font-medium">
                    {formatDate(leave.startDate)} - {formatDate(leave.endDate)}
                  </div>
                  <div className="text-sm text-gray-500">{leave.totalDays} business days</div>
                </div>
                <div>
                  <div className="text-sm text-gray-600">Applied On</div>
                  <div className="font-medium">
                    {formatDate(leave.createdAt)}
                  </div>
                </div>
                <div>
                  <div className="text-sm text-gray-600">Status</div>
                  <div className="font-medium capitalize text-yellow-600">
                    {leave.status}
                  </div>
                </div>
              </div>
              
              <div className="mb-4">
                <div className="text-sm text-gray-600 mb-1">Reason</div>
                <div className="text-gray-900 bg-gray-50 p-3 rounded border-l-4 border-blue-400">
                  {leave.reason}
                </div>
              </div>
              
              <div className="flex space-x-3">
                <button
                  onClick={() => handleApproval(leave._id, 'approve')}
                  disabled={processingId === leave._id}
                  className="flex-1 bg-green-600 text-white py-2 px-4 rounded hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 disabled:opacity-50"
                >
                  {processingId === leave._id ? 'Processing...' : 'Approve'}
                </button>
                <button
                  onClick={() => {
                    const reason = prompt('Please provide a reason for rejection:');
                    if (reason) {
                      handleApproval(leave._id, 'reject', reason);
                    }
                  }}
                  disabled={processingId === leave._id}
                  className="flex-1 bg-red-600 text-white py-2 px-4 rounded hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 disabled:opacity-50"
                >
                  {processingId === leave._id ? 'Processing...' : 'Reject'}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default LeaveApprovalDashboard;