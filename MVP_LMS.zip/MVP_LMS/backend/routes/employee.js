import express from 'express';
import Employee from '../models/Employee.js';
import LeaveBalance from '../models/LeaveBalance.js';


const router = express.Router();
// Add new employee with comprehensive validation
router.post('/', async (req, res) => {
  try {
    const {
  name,
  email,
  department,
  joiningDate,
  managerId: rawManagerId
} = req.body;

const managerId = rawManagerId || undefined;
    
    // Edge case: Validate joining date
    const joining = new Date(joiningDate);
    const today = new Date();
    if (joining > today) {
      return res.status(400).json({ error: 'Joining date cannot be in the future' });
    }
    
    // Edge case: Check if manager exists
    if (managerId) {
      const manager = await Employee.findById(managerId);
      if (!manager) {
        return res.status(400).json({ error: 'Manager not found' });
      }
    }
    
    // Generate unique employee ID
    const lastEmployee = await Employee.findOne().sort({ employeeId: -1 });
    const employeeId = lastEmployee ? 
      `EMP${(parseInt(lastEmployee.employeeId.slice(3)) + 1).toString().padStart(3, '0')}` : 
      'EMP001';
    
    const employee = new Employee({
      employeeId,
      name: name.trim(),
      email: email.toLowerCase().trim(),
      department: department.trim(),
      managerId,
      joiningDate: joining
    });
    
    await employee.save();
    
    // Initialize leave balances for current year
    await initializeLeaveBalance(employee._id, new Date().getFullYear());
    
    res.status(201).json(employee);
  } catch (error) {
    if (error.code === 11000) {
      return res.status(400).json({ error: 'Employee with this email already exists' });
    }
    res.status(400).json({ error: error.message });
  }
});

// Initialize leave balance helper function
async function initializeLeaveBalance(employeeId, year) {
  const employee = await Employee.findById(employeeId);
  const leaveTypes = ['annual', 'sick', 'personal'];
  
  for (const type of leaveTypes) {
    const allocated = employee.leavePolicy[`${type}Leave`] || 0;
    
    // Pro-rate for employees joining mid-year
    const joiningYear = employee.joiningDate.getFullYear();
    const proRatedAllocation = joiningYear === year ? 
      Math.floor(allocated * (12 - employee.joiningDate.getMonth()) / 12) : 
      allocated;
    
    await LeaveBalance.create({
      employeeId,
      year,
      leaveType: type,
      allocated: proRatedAllocation,
      available: proRatedAllocation
    });
  }
}

// Get all employees with pagination and filtering
router.get('/', async (req, res) => {
  try {
    const { page = 1, limit = 10, department, status = 'active' } = req.query;
    const filter = { status };
    
    if (department) filter.department = department;
    
    const employees = await Employee.find(filter)
      .populate('managerId', 'name employeeId')
      .limit(limit * 1)
      .skip((page - 1) * limit)
      .sort({ createdAt: -1 });
    
    const total = await Employee.countDocuments(filter);
    
    res.json({
      employees,
      totalPages: Math.ceil(total / limit),
      currentPage: page,
      total
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export default router;
