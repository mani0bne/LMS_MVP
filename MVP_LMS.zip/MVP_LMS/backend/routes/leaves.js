import express from 'express';
import Leave from '../models/Leave.js';
import LeaveBalance from '../models/LeaveBalance.js';
import Employee from '../models/Employee.js';

const router = express.Router();

/**
 * Utility: find employee by Mongo _id or custom employeeId
 */
async function findEmployee(employeeId) {
  return await Employee.findOne({
    $or: [
      { _id: employeeId },
      { employeeId: employeeId }
    ]
  });
}

/**
 * Apply for leave
 */
router.post('/', async (req, res) => {
  try {
    const { employeeId, leaveType, startDate, endDate, reason, emergencyLeave = false } = req.body;

    // ✅ Find employee by either _id or EMPxxx
    const employee = await findEmployee(employeeId);
    if (!employee) {
      return res.status(404).json({ error: 'Employee not found' });
    }

    // ✅ Check employee status
    if (employee.status !== 'active') {
      return res.status(400).json({ error: 'Cannot apply leave for inactive employee' });
    }

    const start = new Date(startDate);
    const end = new Date(endDate);
    const today = new Date();

    // ✅ Validate dates
    if (start > end) {
      return res.status(400).json({ error: 'Start date cannot be after end date' });
    }

    if (!emergencyLeave && start < today) {
      return res.status(400).json({ error: 'Cannot apply leave for past dates' });
    }

    if (start < employee.joiningDate) {
      return res.status(400).json({ error: 'Cannot apply leave before joining date' });
    }

    const totalDays = calculateBusinessDays(start, end);
    if (totalDays <= 0) {
      return res.status(400).json({ error: 'Leave period must include business days' });
    }

    // ✅ Check overlapping leave
    const overlappingLeave = await Leave.findOne({
      employeeId: employee._id,
      status: { $in: ['pending', 'approved'] },
      $or: [{ startDate: { $lte: end }, endDate: { $gte: start } }]
    });

    if (overlappingLeave) {
      return res.status(400).json({ error: 'Overlapping leave request exists' });
    }

    // ✅ Check leave balance
    const currentYear = start.getFullYear();
    const leaveBalance = await LeaveBalance.findOne({
      employeeId: employee._id,
      year: currentYear,
      leaveType
    });

    if (!leaveBalance) {
      return res.status(400).json({ error: 'Leave balance not found for this type' });
    }

    if (!emergencyLeave && leaveBalance.available < totalDays) {
      return res.status(400).json({
        error: `Insufficient leave balance. Available: ${leaveBalance.available}, Requested: ${totalDays}`
      });
    }

    // ✅ Create leave application
    const leave = new Leave({
      employeeId: employee._id,
      leaveType,
      startDate: start,
      endDate: end,
      totalDays,
      reason: reason.trim(),
      emergencyLeave
    });

    await leave.save();

    // ✅ Update leave balance (move from available → pending)
    await LeaveBalance.updateOne(
      { employeeId: employee._id, year: currentYear, leaveType },
      { $inc: { pending: totalDays, available: -totalDays } }
    );

    res.status(201).json(leave);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

/**
 * Approve / Reject leave
 */
router.put('/:id/:action', async (req, res) => {
  try {
    const { id, action } = req.params;
    const { approverId, rejectionReason } = req.body;

    if (!['approve', 'reject'].includes(action)) {
      return res.status(400).json({ error: 'Invalid action' });
    }

    const leave = await Leave.findById(id).populate('employeeId');
    if (!leave) {
      return res.status(404).json({ error: 'Leave request not found' });
    }

    if (leave.status !== 'pending') {
      return res.status(400).json({ error: 'Leave request already processed' });
    }

    const approver = await findEmployee(approverId);
    if (!approver) {
      return res.status(404).json({ error: 'Approver not found' });
    }

    // ✅ Authorization check
    if (
      leave.employeeId.managerId &&
      !leave.employeeId.managerId.equals(approver._id) &&
      approver.department !== 'HR'
    ) {
      return res.status(403).json({ error: 'Not authorized to approve this leave' });
    }

    const currentYear = leave.startDate.getFullYear();

    if (action === 'approve') {
      leave.status = 'approved';
      leave.approvedBy = approver._id;
      leave.approvedAt = new Date();

      await LeaveBalance.updateOne(
        { employeeId: leave.employeeId._id, year: currentYear, leaveType: leave.leaveType },
        { $inc: { pending: -leave.totalDays, used: leave.totalDays } }
      );
    } else {
      leave.status = 'rejected';
      leave.rejectionReason = rejectionReason;

      await LeaveBalance.updateOne(
        { employeeId: leave.employeeId._id, year: currentYear, leaveType: leave.leaveType },
        { $inc: { pending: -leave.totalDays, available: leave.totalDays } }
      );
    }

    await leave.save();
    res.json(leave);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

/**
 * Get leave balance for employee
 */
router.get('/balance/:employeeId', async (req, res) => {
  try {
    const { employeeId } = req.params;
    const year = req.query.year || new Date().getFullYear();

    const employee = await findEmployee(employeeId);
    if (!employee) {
      return res.status(404).json({ error: 'Employee not found' });
    }

    let balances = await LeaveBalance.find({ employeeId: employee._id, year });

    if (balances.length === 0) {
      // Initialize if missing
      await initializeLeaveBalance(employee._id, year);
      balances = await LeaveBalance.find({ employeeId: employee._id, year });
    }

    res.json(balances);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

/**
 * Helper: Calculate business days (Mon–Fri)
 */
function calculateBusinessDays(startDate, endDate) {
  let count = 0;
  const current = new Date(startDate);

  while (current <= endDate) {
    const dayOfWeek = current.getDay();
    if (dayOfWeek !== 0 && dayOfWeek !== 6) {
      count++;
    }
    current.setDate(current.getDate() + 1);
  }

  return count;
}

/**
 * Helper: Initialize leave balance (same as in employee routes)
 */
async function initializeLeaveBalance(employeeId, year) {
  const employee = await Employee.findById(employeeId);
  const leaveTypes = ['annual', 'sick', 'personal'];

  for (const type of leaveTypes) {
    const allocated = employee.leavePolicy[`${type}Leave`] || 0;
    const joiningYear = employee.joiningDate.getFullYear();

    const proRatedAllocation =
      joiningYear === year
        ? Math.floor((allocated * (12 - employee.joiningDate.getMonth())) / 12)
        : allocated;

    await LeaveBalance.create({
      employeeId,
      year,
      leaveType: type,
      allocated: proRatedAllocation,
      available: proRatedAllocation
    });
  }
}

export default router;
