import mongoose from "mongoose";
const leaveBalanceSchema = new mongoose.Schema({
  employeeId: { type: mongoose.Schema.Types.ObjectId, ref: 'Employee', required: true },
  year: { type: Number, required: true },
  leaveType: { type: String, required: true },
  allocated: { type: Number, required: true },
  used: { type: Number, default: 0 },
  pending: { type: Number, default: 0 },
  available: { type: Number, required: true },
  carriedOver: { type: Number, default: 0 }
}, { timestamps: true });

leaveBalanceSchema.index({ employeeId: 1, year: 1, leaveType: 1 }, { unique: true });

export default mongoose.model("LeaveBalance", leaveBalanceSchema);