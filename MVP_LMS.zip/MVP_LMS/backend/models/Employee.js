import mongoose from "mongoose";

const employeeSchema = new mongoose.Schema({
  employeeId: { type: String, required: true, unique: true },
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  department: { type: String, required: true },
  managerId: { type: mongoose.Schema.Types.ObjectId, ref: 'Employee' },
  joiningDate: { type: Date, required: true },
  status: { type: String, enum: ['active', 'inactive', 'terminated'], default: 'active' },
  leavePolicy: {
    annualLeave: { type: Number, default: 20 },
    sickLeave: { type: Number, default: 10 },
    personalLeave: { type: Number, default: 5 }
  }
}, { timestamps: true });

export default mongoose.model("Employee", employeeSchema);